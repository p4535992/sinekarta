package org.sinekartads.dto.jcl;


public class PreSignResponseDTO extends JclResponseDTO {

	private static final long serialVersionUID = -680574047309335295L;
}
