package org.sinekartads.util;

public interface EntityFilter<Entity> {
	
	public boolean match ( Entity certificate ) ;
}
