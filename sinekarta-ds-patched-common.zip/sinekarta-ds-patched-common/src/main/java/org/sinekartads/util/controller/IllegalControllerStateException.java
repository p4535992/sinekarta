package org.sinekartads.util.controller;

public class IllegalControllerStateException extends IllegalStateException {

	private static final long serialVersionUID = 344858925672483899L;

	public IllegalControllerStateException(String message) {
		super(message);
	}
}