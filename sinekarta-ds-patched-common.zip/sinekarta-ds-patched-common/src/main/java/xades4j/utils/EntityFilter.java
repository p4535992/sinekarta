package xades4j.utils;

public interface EntityFilter<Entity> {
	
	public boolean match ( Entity certificate ) ;
}
